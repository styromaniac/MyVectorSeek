
# Bootstrap one-liner (embedded for self-contained recovery)
# Usage: paste this line in Termux to reinstall refine
echo 'REFINE_CMD="echo \"[INFO] Starting refine automation (self-updating, no-hang, full recursion)...\" && TOKEN_FILE=~/.git_token && GITHUB_TOKEN=\$(cat \"$TOKEN_FILE\" 2>/dev/null || echo \"MISSING\") && if [ \"$GITHUB_TOKEN\" = \"MISSING\" ]; then echo \"[WARNING] GitHub token missing. Push will be skipped.\"; else echo \"[INFO] GitHub token loaded successfully.\"; fi && BUILD_TIMESTAMP=\$(date +%Y-%m-%d_%H-%M-%S) && termux-wake-lock && echo \"[INFO] Wake lock activated.\" && echo \"[INFO] Checking for refine script updates...\" && UPDATE_URL=\"https://raw.githubusercontent.com/styromaniac/RefineAA/main/scripts/refine.sh\" && TMP_UPDATE=~/refine_update.sh && curl -fsSL \"$UPDATE_URL\" -o \"$TMP_UPDATE\" && if ! cmp -s \"$TMP_UPDATE\" ~/../usr/bin/refine; then echo \"[INFO] New refine version found. Updating...\" && mv \"$TMP_UPDATE\" ~/../usr/bin/refine && chmod +x ~/../usr/bin/refine && echo \"[INFO] Refine self-update complete.\"; else echo \"[INFO] Refine is up to date.\"; fi && echo \"[INFO] Cleaning environment...\" && rm -rf ~/RefineAA && mkdir -p ~/RefineAA && cd ~/RefineAA && echo \"[INFO] Cloning existing GitHub repository...\" && if [ \"$GITHUB_TOKEN\" = \"MISSING\" ]; then echo \"[ERROR] Missing GitHub token. Cannot clone remote repo.\" && exit 1; fi && git clone https://$GITHUB_TOKEN@github.com/styromaniac/RefineAA.git . && echo \"[INFO] Downloading latest RefineAA bulletproof release...\" && LATEST_URL=\$(curl -fsSL https://api.github.com/repos/styromaniac/RefineAA/releases/latest | grep \"browser_download_url\" | grep \"RefineAA_bulletproof.zip\" | cut -d \" -f 4) && if [ -z \"$LATEST_URL\" ]; then echo \"[WARNING] No release URL found. Skipping download.\"; else curl -Lo RefineAA.zip \"$LATEST_URL\" --fail --silent --show-error && echo \"[INFO] Extracting RefineAA.zip into repository...\" && unzip -o RefineAA.zip; fi && echo \"[INFO] Running installer...\" && chmod +x ~/RefineAA/scripts/RefineAA_Installer.sh && bash ~/RefineAA/scripts/RefineAA_Installer.sh && echo \"[INFO] Sanitizing environment from PATs...\" && PAT=\$(cat ~/.git_token 2>/dev/null || echo \"NO_TOKEN_PRESENT\") && if [ \"$PAT\" != \"NO_TOKEN_PRESENT\" ]; then grep -rl --exclude=\".git_token\" --exclude-dir=\".git\" --exclude=\"*.git/config\" --exclude-dir=\"node_modules\" --exclude-dir=\"vendor\" \"$PAT\" ~/RefineAA ~/.termux 2>/dev/null | xargs sed -i \"\" -e \"/$PAT/d\" && echo \"[INFO] Local sanitization complete.\"; fi && echo \"[INFO] Updating README.md build timestamp...\" && sed -i \"\" -e \"s/Build Timestamp:.*/Build Timestamp: $BUILD_TIMESTAMP/\" ~/RefineAA/README.md || echo \"[WARNING] Failed to update README.md.\" && echo \"[INFO] Archiving conversation and refine command...\" && mkdir -p ~/RefineAA_Conversation && history > ~/RefineAA_Conversation/conversation_history.txt && echo \"$REFINE_CMD\" > ~/RefineAA_Conversation/refine_self_contained.sh && echo \"Final deployment: clone-first, self-updating, sanitize, snapshot, push-confirmed, clean exit, bootstrap sync.\" > ~/RefineAA_Conversation/forward_thinking.txt && echo \"$REFINE_CMD\" > ~/RefineAA_Conversation/latest_refine_oneliner.txt && SNAPSHOT=~/FullEnv_snapshot_\$(date +%Y%m%d-%H%M%S).zip && echo \"[INFO] Creating snapshot: $SNAPSHOT\" && zip -r --quiet --exclude \".git_token\" --exclude \"*.git_token\" --exclude \".git/config\" --exclude \".git/objects/*\" \"$SNAPSHOT\" ~/RefineAA ~/.termux ~/RefineAA_Conversation . && echo \"[INFO] Preparing commit and push...\" && cd ~/RefineAA && git add --all && git commit -m \"Auto snapshot $BUILD_TIMESTAMP\" || echo \"[INFO] Nothing to commit.\" && echo \"[INFO] Pushing to GitHub repository...\" && GIT_PUSH_OUTPUT=\$(git push --force 2>&1) && GIT_PUSH_EXIT=\$? && echo \"$GIT_PUSH_OUTPUT\" && if [ \"$GIT_PUSH_EXIT\" -eq 0 ]; then echo \"[SUCCESS] Git push complete — repository updated.\"; else echo \"[ERROR] Git push failed — repository not updated.\" && echo \"[DETAILS] Git push error output:\" && echo \"$GIT_PUSH_OUTPUT\"; fi && echo \"[INFO] Full environment snapshot saved to $SNAPSHOT\"' | tee ~/../usr/bin/refine | awk 1 && chmod +x ~/../usr/bin/refine



#!/data/data/com.termux/files/usr/bin/bash

echo "[INFO] Starting refine automation with full Termux reconfiguration..."

# Full Termux setup from scratch (safe for repeat runs)
pkg update -y && pkg upgrade -y
pkg install -y git curl unzip zip termux-api proot tar wget

# Ensure necessary paths
mkdir -p ~/RefineAA
mkdir -p ~/RefineAA_Conversation

# Self-update logic
UPDATE_URL="https://raw.githubusercontent.com/styromaniac/RefineAA/main/scripts/refine.sh"
TMP_UPDATE=~/refine_update.sh
curl -fsSL "$UPDATE_URL" -o "$TMP_UPDATE"
if ! cmp -s "$TMP_UPDATE" ~/../usr/bin/refine; then
    echo "[INFO] Refine script update detected, applying..."
    mv "$TMP_UPDATE" ~/../usr/bin/refine
    chmod +x ~/../usr/bin/refine
    echo "[INFO] Refine self-update complete."
fi

# Token handling
TOKEN_FILE=~/.git_token
GITHUB_TOKEN=$(cat "$TOKEN_FILE" 2>/dev/null || echo "MISSING")
if [ "$GITHUB_TOKEN" = "MISSING" ]; then
    echo "[ERROR] GitHub token missing. Cannot continue."
    exit 1
fi

# Environment cleanup
rm -rf ~/RefineAA
mkdir -p ~/RefineAA
cd ~/RefineAA

# Clone repo
echo "[INFO] Cloning RefineAA repository..."
git clone https://$GITHUB_TOKEN@github.com/styromaniac/RefineAA.git .

# Download and extract latest release
LATEST_URL=$(curl -fsSL https://api.github.com/repos/styromaniac/RefineAA/releases/latest | grep "browser_download_url" | grep "RefineAA_bulletproof.zip" | cut -d '"' -f 4)
if [ -n "$LATEST_URL" ]; then
    curl -Lo RefineAA.zip "$LATEST_URL" --fail --silent --show-error
    unzip -o RefineAA.zip
fi

# Run installer
chmod +x scripts/RefineAA_Installer.sh
bash scripts/RefineAA_Installer.sh

# Sanitize environment
PAT=$(cat ~/.git_token 2>/dev/null || echo "NO_TOKEN_PRESENT")
if [ "$PAT" != "NO_TOKEN_PRESENT" ]; then
    grep -rl --exclude=".git_token" --exclude-dir=".git" --exclude="*.git/config" "$PAT" ~/RefineAA ~/.termux 2>/dev/null | xargs sed -i "" -e "/$PAT/d"
fi

# Update README.md timestamp
BUILD_TIMESTAMP=$(date +%Y-%m-%d_%H-%M-%S)
sed -i "" -e "s/Build Timestamp:.*/Build Timestamp: $BUILD_TIMESTAMP/" ~/RefineAA/README.md

# Archive refine and conversation
echo "$0" > ~/RefineAA_Conversation/refine_self_contained.sh
history > ~/RefineAA_Conversation/conversation_history.txt
echo "Final deployment: full Termux reconfiguration, self-healing refine." > ~/RefineAA_Conversation/forward_thinking.txt

SNAPSHOT=~/FullEnv_snapshot_$(date +%Y%m%d-%H%M%S).zip
zip -r --quiet --exclude ".git_token" --exclude "*.git_token" --exclude ".git/config" "$SNAPSHOT" ~/RefineAA ~/.termux ~/RefineAA_Conversation .

# Push to GitHub
cd ~/RefineAA
git add --all
git commit -m "Auto snapshot $BUILD_TIMESTAMP" || echo "[INFO] Nothing to commit."
git push --force

echo "[INFO] Full environment snapshot saved to $SNAPSHOT"
